BOTNAME = "usernameofbot"
TOKEN = "TOKEN"
